# Custom tools for the Tutorial Generator agent
# Add @tool decorated functions here if needed

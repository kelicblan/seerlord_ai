import type { Updater } from "@tanstack/vue-table"
import type { ClassValue } from "clsx"
import type { Ref } from "vue"
import { clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function valueUpdater<T extends Updater<any>>(updaterOrValue: T, ref: Ref) {
  ref.value
    = typeof updaterOrValue === "function"
      ? updaterOrValue(ref.value)
      : updaterOrValue
}

export function getLocalizedText(text: string | null | undefined, locale: string): string {
  if (!text) return ''
  try {
    const json = JSON.parse(text) as Record<string, string>
    if (typeof json === 'object' && json !== null) {
      // Try exact match
      if (json[locale]) return json[locale]
      
      // Try language code (e.g. 'zh' from 'zh-CN')
      const lang = locale.split('-')[0]
      if (lang && json[lang]) return json[lang]
      
      // Fallback to 'en' or first key
      if (json['en']) return json['en']
      const keys = Object.keys(json)
      const firstKey = keys[0]
      if (firstKey && json[firstKey]) return json[firstKey]
    }
  } catch (e) {
    // Not JSON, return original
  }
  return text
}
